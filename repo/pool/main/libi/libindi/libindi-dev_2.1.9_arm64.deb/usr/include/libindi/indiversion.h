/* Set INDI Library version */
#define INDI_VERSION_MAJOR   2
#define INDI_VERSION_MINOR   1
#define INDI_VERSION_RELEASE 9
#define INDI_VERSION "2.1.9"

/* Define INDI Data Dir */
#define DATA_INSTALL_DIR "/usr/share/indi/"
